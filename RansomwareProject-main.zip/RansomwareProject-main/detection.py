import json
import time
from collections import defaultdict
import os
import psutil

LOG_FILE = "integrity_log.json"

SUSPICIOUS_EXTENSIONS = [".enc", ".locked", ".crypted"]
RANSOM_KEYWORDS = ["your files have been encrypted", "decrypt", "bitcoin"]

def load_logs():
    with open(LOG_FILE, "r") as f:
        return json.load(f)

def check_file_extension(path):
    return any(path.lower().endswith(ext) for ext in SUSPICIOUS_EXTENSIONS)

def check_ransom_note_content(path):
    try:
        with open(path, "r", errors="ignore") as f:
            content = f.read().lower()
            print(content)
            return any(word in content for word in RANSOM_KEYWORDS)
    except:
        return False

def detect_policy_violations(logs):
    file_mod_times = defaultdict(list)
    ransomware_detected = False

    for log in logs:
        event = log["event"]
        path = log["file"]
        timestamp = time.mktime(time.strptime(log["time"], "%Y-%m-%d %H:%M:%S"))
        
        # Rule 1: Burst of modified files
        if event == "MODIFIED FILE":
            file_mod_times["modified"].append(timestamp)
        
        # Rule 2: Suspicious file extensions
        if event == "NEW FILE" and check_file_extension(path):
            print(f"[ALERT] Suspicious file extension detected: {path}")
            ransomware_detected = True
        
        # Rule 3: Ransom note content
        if event == "NEW FILE" and path.endswith((".txt", ".html")):
            if check_ransom_note_content(path):
                print(f"[ALERT] Ransom note detected: {path}")
                ransomware_detected = True

    # Analyze for burst modification rule
    times = sorted(file_mod_times["modified"])
    for i in range(len(times)):
        burst = [t for t in times if times[i] <= t <= times[i] + 30]
        if len(burst) > 20:
            print(f"[ALERT] Burst of file modifications detected: {len(burst)} in 30s")
            ransomware_detected = True
            break

    if not ransomware_detected:
        print("[OK] No ransomware activity detected.")
    else:
        trigger_mitigation()
    return ransomware_detected



# ===  Isolate the System from Network ===
def isolate_system():
    try:
        os.system("ipconfig /release")  # Windows command to disconnect network
        print("[ACTION] Network disconnected to prevent ransomware spread.")
    except Exception as e:
        print(f"[ERROR] Failed to isolate system: {e}")

# ===  Kill Suspicious Processes ===
def kill_suspicious_processes():
    try:
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'io_counters']):
            try:
                io = proc.info['io_counters']
                if io and io.write_bytes > 10_000_000:  # Threshold: >10MB written = suspicious
                    proc.kill()
                    print(f"[ACTION] Killed suspicious process: {proc.info['name']} (PID {proc.info['pid']})")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except Exception as e:
        print(f"[ERROR] Failed to kill processes: {e}")

# ===  Full Mitigation Trigger ===
def trigger_mitigation():
    print("\n[!] Mitigation Started...")
    isolate_system()
    kill_suspicious_processes()
    print("[!] Mitigation Completed.\n")

if __name__ == "__main__":
    while True:
        logs = load_logs()
        detect_policy_violations(logs)
        time.sleep(10)
