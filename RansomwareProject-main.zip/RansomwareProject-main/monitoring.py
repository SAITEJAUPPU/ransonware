import os
import hashlib
import json
import time

# Directory to monitor
MONITOR_DIR = r"C:\Users\rashm\Desktop\Confidential"
BASELINE_FILE = "file_baseline.json"
LOG_FILE = "integrity_log.json"

# Hashing function (SHA-256)
def hash_file(path):
    sha256 = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while chunk := f.read(8192):
                sha256.update(chunk)
        return sha256.hexdigest()
    except Exception as e:
        return str(e)

# Load baseline or create if it doesn't exist
def create_baseline():
    baseline = {}
    for root, _, files in os.walk(MONITOR_DIR):
        for file in files:
            path = os.path.join(root, file)
            baseline[path] = hash_file(path)
    with open(BASELINE_FILE, "w") as f:
        json.dump(baseline, f, indent=2)

# Load existing baseline
def load_baseline():
    if not os.path.exists(BASELINE_FILE):
        create_baseline()
    with open(BASELINE_FILE, "r") as f:
        return json.load(f)

# Log suspicious changes
def log_event(event_type, path):
    log_entry = {
        "event": event_type,
        "file": path,
        "time": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r") as f:
            logs = json.load(f)
    else:
        logs = []
    logs.append(log_entry)
    with open(LOG_FILE, "w") as f:
        json.dump(logs, f, indent=2)
    print(f"[!] {event_type} detected: {path}")

# Monitor for changes
def monitor():
    baseline = load_baseline()
    current = {}

    for root, _, files in os.walk(MONITOR_DIR):
        for file in files:
            path = os.path.join(root, file)
            current[path] = hash_file(path)

    # Check for modified or new files
    for path, hash_val in current.items():
        if path not in baseline:
            log_event("NEW FILE", path)
        elif hash_val != baseline[path]:
            log_event("MODIFIED FILE", path)

    # Check for deleted files
    for path in baseline:
        if path not in current:
            log_event("DELETED FILE", path)

    # Update baseline if needed (optional)
    # with open(BASELINE_FILE, "w") as f:
    #     json.dump(current, f, indent=2)

if __name__ == "__main__":
    print("[*] Monitoring for ransomware-like activity...")
    while True:
        monitor()
        time.sleep(10)  # Scan interval (in seconds)
